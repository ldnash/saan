# proxy
A simple JSON, XML, and text proxy.
